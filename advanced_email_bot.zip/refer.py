ython3
"""
ATP Network Temporary Email Bot - single-file installer/launcher.

This file creates config.py, refer.py and requirements.txt automatically,
then installs missing dependencies and starts the bot.

For VPS:
    nano main.py
    # paste this file, save, exit
    python3 main.py

The generated email format is:
    atpnetwork###########@uberip.com
where ########### is 11 random digits.

IMPORTANT:
The configured email domain must actually be supported by the email API.
"""

from pathlib import Path
import subprocess
import sys
import os

BASE = Path(__file__).resolve().parent

CONFIG_TEXT = r

import config
import refer

import os
import re
import html
import random
import string
import logging
import requests
from datetime import datetime, timezone

from telegram import (
    Update,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
)
from telegram.ext import (
    ApplicationBuilder,
    CommandHandler,
    CallbackQueryHandler,
    MessageHandler,
    ContextTypes,
    filters,
)


# ============================================================
# CONFIG
# ============================================================

BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip() or config.BOT_TOKEN.strip()
OWNER_ID = int(config.OWNER_ID)
FORCE_JOIN_CHANNEL = config.FORCE_JOIN_CHANNEL.strip()
FORCE_JOIN_URL = config.FORCE_JOIN_URL.strip()
REQUIRED_REFERRALS = int(config.REQUIRED_REFERRALS)
AUTO_CHECK_SECONDS = int(config.AUTO_CHECK_SECONDS)

API = "https://api.mail.tm"

# One successful referral is required before creating an email.
REQUIRED_REFERRALS = 1

# Mailboxes are kept in memory for the running bot.
# They are intentionally separate from refer.db.
mailboxes = {}

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)

logger = logging.getLogger(__name__)

session = requests.Session()
session.headers.update({
    "User-Agent": "AdvancedEmailBot/1.0",
    "Accept": "application/json",
})


# ============================================================
# HELPERS
# ============================================================

def random_string(length=12):
    chars = string.ascii_lowercase + string.digits
    return "".join(random.choices(chars, k=length))


def clean_text(text):
    if not text:
        return ""

    text = html.unescape(text)

    def replace_link(match):
        url = html.unescape(match.group(1)).strip()
        label = re.sub(r"<[^>]+>", "", match.group(2)).strip()
        return f"{label}\n{url}" if label else url

    text = re.sub(
        r'<a[^>]+href=["\']([^"\']+)["\'][^>]*>(.*?)</a>',
        replace_link,
        text,
        flags=re.I | re.S,
    )

    text = re.sub(r"<br\s*/?>", "\n", text, flags=re.I)
    text = re.sub(r"</p>", "\n", text, flags=re.I)
    text = re.sub(r"</div>", "\n", text, flags=re.I)
    text = re.sub(r"<[^>]+>", "", text)

    return re.sub(r"\n\s*\n\s*\n+", "\n\n", text).strip()


def extract_links(text):
    if not text:
        return []

    links = re.findall(
        r'https?://[^\s<>"\']+',
        html.unescape(text),
        flags=re.I,
    )

    result = []
    for link in links:
        link = link.rstrip(".,;:!?)\"]'")
        if link not in result:
            result.append(link)

    return result


def find_otp(text):
    if not text:
        return None

    patterns = [
        r"(?:otp|code|verification|verify|pin)\s*(?:is|:|-)?\s*([0-9]{4,8})\b",
        r"\b([0-9]{6})\b",
        r"\b([0-9]{4,8})\b",
    ]

    for pattern in patterns:
        match = re.search(pattern, text, re.I)
        if match:
            value = match.group(1)
            if not re.fullmatch(r"20\d{2}", value):
                return value

    return None


def api_request(method, url, **kwargs):
    kwargs.setdefault("timeout", 20)
    response = session.request(method, url, **kwargs)
    return response


def get_domain():
    configured_domain = str(getattr(config, "EMAIL_DOMAIN", "")).strip().lstrip("@")
    if configured_domain:
        return configured_domain

    response = api_request("GET", f"{API}/domains")
    response.raise_for_status()
    data = response.json()

    if isinstance(data, list):
        domains = data
    elif isinstance(data, dict):
        domains = data.get("hydra:member", [])
    else:
        raise RuntimeError("Unexpected email service /domains response.")

    if not domains:
        raise RuntimeError("No email service domains are available.")

    for item in domains:
        if isinstance(item, dict) and item.get("domain"):
            if item.get("isActive", True):
                return item["domain"]
        elif isinstance(item, str):
            return item

    first = domains[0]
    if isinstance(first, dict) and first.get("domain"):
        return first["domain"]
    if isinstance(first, str):
        return first

    raise RuntimeError("Could not determine a email service domain.")



def make_email_address(domain):
    prefix = str(getattr(config, "EMAIL_PREFIX", "atpnetwork"))
    digits = int(getattr(config, "EMAIL_RANDOM_DIGITS", 11))
    configured_domain = str(getattr(config, "EMAIL_DOMAIN", "")).strip().lstrip("@")
    final_domain = configured_domain or domain
    number = "".join(random.choice(string.digits) for _ in range(digits))
    return f"{prefix}{number}@{final_domain}"


def create_mailbox():
    domain = get_domain()

    address = make_email_address(domain)
    password = random_string(20)

    payload = {
        "address": address,
        "password": password,
    }

    response = api_request(
        "POST",
        f"{API}/accounts",
        json=payload,
    )

    if response.status_code not in (200, 201):
        raise RuntimeError(
            f"Account creation failed: HTTP {response.status_code}"
        )

    response = api_request(
        "POST",
        f"{API}/token",
        json=payload,
    )
    response.raise_for_status()

    token = response.json().get("token")
    if not token:
        raise RuntimeError("email service did not return a token.")

    return {
        "email": address,
        "password": password,
        "token": token,
    }


def auth_headers(user_id):
    mailbox = mailboxes.get(user_id)
    if not mailbox:
        raise RuntimeError("No mailbox exists for this user.")

    return {
        "Authorization": f"Bearer {mailbox['token']}",
        "Accept": "application/json",
    }


def get_messages(user_id):
    response = api_request(
        "GET",
        f"{API}/messages",
        headers=auth_headers(user_id),
    )
    response.raise_for_status()

    data = response.json()

    if isinstance(data, list):
        return data
    if isinstance(data, dict):
        return data.get("hydra:member", [])
    return []


def get_message(user_id, message_id):
    response = api_request(
        "GET",
        f"{API}/messages/{message_id}",
        headers=auth_headers(user_id),
    )
    response.raise_for_status()
    return response.json()


def message_text(message):
    text = message.get("text", "")
    raw_html = message.get("html", "")

    if isinstance(raw_html, list):
        raw_html = "\n".join(raw_html)

    body = clean_text(text) if text else clean_text(raw_html)

    if not body:
        body = message.get("intro", "No message content.")

    return body, raw_html


def format_full_email(message):
    sender = message.get("from", {})
    if isinstance(sender, dict):
        sender = sender.get("address", "Unknown")

    subject = message.get("subject") or "(No subject)"

    body, raw_html = message_text(message)

    links = extract_links(raw_html)
    links.extend(extract_links(body))

    unique_links = []
    for link in links:
        if link not in unique_links:
            unique_links.append(link)

    otp = find_otp(body)

    lines = [
        f"📨 <b>{html.escape(subject)}</b>",
        "",
        f"<b>From:</b> {html.escape(str(sender))}",
        "",
        "<b>Message:</b>",
        html.escape(body[:3500]),
    ]

    if otp:
        lines += [
            "",
            f"🔑 <b>OTP / CODE:</b> <code>{html.escape(otp)}</code>",
        ]

    if unique_links:
        lines += ["", "🔗 <b>Links:</b>"]
        for i, link in enumerate(unique_links[:10], 1):
            lines.append(f"{i}. <code>{html.escape(link[:1000])}</code>")

    return "\n".join(lines), otp, unique_links


# ============================================================
# KEYBOARDS
# ============================================================

def main_keyboard():
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton(
                "✨ Create New Email",
                callback_data="create_email",
            ),
        ],
        [
            InlineKeyboardButton(
                "🎟️ Redeem Promo",
                callback_data="promo",
            ),
        ],
        [
            InlineKeyboardButton(
                "📥 My Inbox",
                callback_data="inbox",
            ),
            InlineKeyboardButton(
                "⚡ Auto Check",
                callback_data="autocheck",
            ),
        ],
        [
            InlineKeyboardButton(
                "🤝 Referral",
                callback_data="referral",
            ),
            InlineKeyboardButton(
                "📊 My Stats",
                callback_data="stats",
            ),
        ],
        [
            InlineKeyboardButton(
                "👑 Owner Dashboard",
                callback_data="owner_dashboard",
            ),
        ],
        [
            InlineKeyboardButton(
                "💬 Support • @atp_network",
                url="https://t.me/atp_network",
            ),
        ],
    ])


# ============================================================
# START / REFERRALS
# ============================================================

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    user_id = user.id

    referrer_id = None

    if context.args:
        payload = context.args[0].strip()

        if payload.startswith("ref_"):
            raw_id = payload[4:]
            if raw_id.isdigit():
                referrer_id = int(raw_id)

    result = refer.register_user(
        user_id,
        referrer_id,
    )

    if result["credited"]:
        referral_text = (
            "\n\n✅ You joined through a referral link. "
            "That referral has been credited."
        )
    elif referrer_id == user_id:
        referral_text = (
            "\n\n⚠️ You cannot refer yourself."
        )
    elif result["new_user"] and referrer_id is not None:
        referral_text = (
            "\n\n⚠️ That referral link could not be credited."
        )
    else:
        referral_text = ""

    count = refer.referral_count(user_id)

    text = (
        "✨ <b>ADVANCED EMAIL</b> ✨\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "📧 <b>Temporary Email Service</b>\n\n"
        "Create a temporary inbox and receive messages "
        "directly here.\n\n"
        f"👥 Referrals  •  <b>{count}/{REQUIRED_REFERRALS}</b>\n"
        f"🎟️ Email Credits  •  <b>{refer.get_credits(user_id)}</b>\n\n"
        f"📌 Complete {REQUIRED_REFERRALS} successful referral "
        "to unlock email creation, or use available credits.\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "🛠️ <b>Bot made by ATP Network</b>\n"
        "💬 Support: @atp_network"
        + referral_text
    )

    await update.message.reply_text(
        text,
        parse_mode="HTML",
        reply_markup=main_keyboard(),
    )


async def referral_page(query):
    user_id = query.from_user.id
    count = refer.referral_count(user_id)

    me = await query.get_bot()
    bot_username = me.username

    link = f"https://t.me/{bot_username}?start=ref_{user_id}"

    text = (
        "🔗 <b>Your Referral</b>\n\n"
        f"👥 Successful referrals: <b>{count}</b>\n"
        f"🎯 Required: <b>{REQUIRED_REFERRALS}</b>\n\n"
        "Share this link with someone who has never started "
        "this bot before:\n\n"
        f"<code>{html.escape(link)}</code>\n\n"
        "⚠️ A user can only be credited once. "
        "If they already started the bot, their later referral "
        "link cannot give referral credit."
    )

    await query.edit_message_text(
        text,
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("⬅️ Back", callback_data="home")]
        ]),
    )


# ============================================================
# CREATE EMAIL
# ============================================================

async def create_email(query):
    user_id = query.from_user.id

    count = refer.referral_count(user_id)
    credits = refer.get_credits(user_id)

    # Promo credits are consumed one per email and bypass the referral requirement.
    using_credit = credits > 0

    if not using_credit and count < REQUIRED_REFERRALS:
        await query.answer(
            "You need a successful referral or an email credit.",
            show_alert=True,
        )
        return

    await query.edit_message_text(
        "⏳ Creating your temporary email..."
    )

    try:
        mailbox = create_mailbox()
        mailboxes[user_id] = mailbox

        if using_credit:
            refer.consume_credit(user_id)

        text = (
            "📧 <b>Temporary Email Created</b>\n\n"
            f"<b>Email:</b>\n"
            f"<code>{html.escape(mailbox['email'])}</code>\n\n"
            "Use <b>Inbox</b> to check incoming emails."
        )

        await query.edit_message_text(
            text,
            parse_mode="HTML",
            reply_markup=main_keyboard(),
        )

    except Exception as e:
        logger.exception("Mailbox creation failed")
        await query.edit_message_text(
            "❌ Could not create the email.\n\n"
            f"<code>{html.escape(str(e)[:1000])}</code>",
            parse_mode="HTML",
            reply_markup=main_keyboard(),
        )


# ============================================================
# INBOX
# ============================================================

async def inbox_page(query):
    user_id = query.from_user.id

    if user_id not in mailboxes:
        await query.answer(
            "Create an email first.",
            show_alert=True,
        )
        return

    try:
        messages = get_messages(user_id)

        if not messages:
            text = "📭 <b>Inbox is empty.</b>"
            keyboard = [
                [InlineKeyboardButton(
                    "🔄 Refresh",
                    callback_data="inbox"
                )],
                [InlineKeyboardButton(
                    "⬅️ Back",
                    callback_data="home"
                )],
            ]

        else:
            lines = ["📥 <b>Inbox</b>\n"]

            buttons = []

            for i, message in enumerate(messages[:20], 1):
                subject = message.get("subject") or "(No subject)"
                sender = message.get("from", {})

                if isinstance(sender, dict):
                    sender = sender.get("address", "Unknown")

                status = "🆕" if not message.get("seen") else "📨"

                lines.append(
                    f"{status} <b>{i}.</b> "
                    f"{html.escape(subject[:80])}\n"
                    f"   {html.escape(str(sender)[:80])}"
                )

                buttons.append([
                    InlineKeyboardButton(
                        f"📨 {i}",
                        callback_data=f"read:{message['id']}",
                    )
                ])

            keyboard = buttons + [
                [
                    InlineKeyboardButton(
                        "🔄 Refresh",
                        callback_data="inbox"
                    ),
                    InlineKeyboardButton(
                        "⬅️ Back",
                        callback_data="home"
                    ),
                ]
            ]

            text = "\n\n".join(lines)

        await query.edit_message_text(
            text,
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup(keyboard),
        )

    except Exception as e:
        await query.edit_message_text(
            "❌ Inbox error:\n"
            f"<code>{html.escape(str(e)[:1000])}</code>",
            parse_mode="HTML",
            reply_markup=main_keyboard(),
        )


# ============================================================
# READ EMAIL
# ============================================================

async def read_selected_email(query, message_id):
    user_id = query.from_user.id

    try:
        message = get_message(
            user_id,
            message_id,
        )

        text, otp, links = format_full_email(
            message
        )

        buttons = [
            [
                InlineKeyboardButton(
                    "⬅️ Inbox",
                    callback_data="inbox",
                )
            ]
        ]

        await query.edit_message_text(
            text,
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup(buttons),
        )

    except Exception as e:
        await query.edit_message_text(
            "❌ Could not read email.\n\n"
            f"<code>{html.escape(str(e)[:1000])}</code>",
            parse_mode="HTML",
            reply_markup=main_keyboard(),
        )


# ============================================================
# AUTO CHECK
# ============================================================

async def autocheck(update_or_query, context):
    query = update_or_query
    user_id = query.from_user.id

    if user_id not in mailboxes:
        await query.answer(
            "Create an email first.",
            show_alert=True,
        )
        return

    # Stop an existing auto-check job for this user.
    if "autocheck_job" in context.user_data:
        old_job = context.user_data["autocheck_job"]
        old_job.schedule_removal()

    try:
        current = get_messages(user_id)
        known_ids = {
            m.get("id")
            for m in current
            if m.get("id")
        }
    except Exception:
        known_ids = set()

    context.user_data["known_ids"] = known_ids

    job = context.job_queue.run_repeating(
        auto_check_job,
        interval=AUTO_CHECK_SECONDS,
        first=5,
        chat_id=query.message.chat_id,
        user_id=user_id,
        name=f"autocheck_{user_id}",
    )

    context.user_data["autocheck_job"] = job

    await query.edit_message_text(
        "🔄 <b>Auto Check Started</b>\n\n"
        "Checking for new emails automatically.\n"
        "New emails will be sent here automatically.",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton(
                "⏹ Stop Auto Check",
                callback_data="stop_autocheck"
            )],
            [InlineKeyboardButton(
                "⬅️ Back",
                callback_data="home"
            )],
        ]),
    )


async def auto_check_job(context: ContextTypes.DEFAULT_TYPE):
    user_id = context.job.user_id

    if user_id not in mailboxes:
        context.job.schedule_removal()
        return

    known_ids = context.user_data.setdefault(
        "known_ids",
        set()
    )

    try:
        messages = get_messages(user_id)
    except Exception:
        return

    for message in reversed(messages):
        message_id = message.get("id")

        if not message_id or message_id in known_ids:
            continue

        known_ids.add(message_id)

        try:
            full = get_message(
                user_id,
                message_id
            )

            text, _, _ = format_full_email(full)

            await context.bot.send_message(
                chat_id=user_id,
                text="📨 <b>NEW EMAIL RECEIVED</b>\n\n" + text,
                parse_mode="HTML",
            )

        except Exception as e:
            logger.exception("Auto-check read failed")


async def stop_autocheck(query, context):
    job = context.user_data.pop(
        "autocheck_job",
        None
    )

    if job:
        job.schedule_removal()

    await query.edit_message_text(
        "⏹ <b>Auto Check Stopped</b>",
        parse_mode="HTML",
        reply_markup=main_keyboard(),
    )


# ============================================================
# PROMO CODES / OWNER DASHBOARD
# ============================================================

def owner_dashboard_keyboard():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🎟️ Create Promo", callback_data="owner_create_promo")],
        [InlineKeyboardButton("📋 Promo Codes", callback_data="owner_promos")],
        [InlineKeyboardButton("📊 Owner Stats", callback_data="owner_stats")],
        [InlineKeyboardButton("⬅️ Back", callback_data="home")],
    ])


def duration_keyboard():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("⏱️ 1 Hour", callback_data="promo_duration:60")],
        [InlineKeyboardButton("📅 1 Day", callback_data="promo_duration:1440")],
        [InlineKeyboardButton("🗓️ 1 Week", callback_data="promo_duration:10080")],
        [InlineKeyboardButton("♾️ Never", callback_data="promo_duration:0")],
        [InlineKeyboardButton("❌ Cancel", callback_data="owner_dashboard")],
    ])


def credits_keyboard():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("1 Credit", callback_data="promo_credits:1")],
        [InlineKeyboardButton("10 Credits", callback_data="promo_credits:10")],
        [InlineKeyboardButton("100 Credits", callback_data="promo_credits:100")],
        [InlineKeyboardButton("1000 Credits", callback_data="promo_credits:1000")],
        [InlineKeyboardButton("❌ Cancel", callback_data="owner_dashboard")],
    ])


def users_keyboard():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("1 User", callback_data="promo_users:1")],
        [InlineKeyboardButton("10 Users", callback_data="promo_users:10")],
        [InlineKeyboardButton("100 Users", callback_data="promo_users:100")],
        [InlineKeyboardButton("1000 Users", callback_data="promo_users:1000")],
        [InlineKeyboardButton("♾️ Unlimited", callback_data="promo_users:-1")],
        [InlineKeyboardButton("❌ Cancel", callback_data="owner_dashboard")],
    ])


def format_duration(minutes):
    if minutes == 0:
        return "Never"
    if minutes == 60:
        return "1 hour"
    if minutes == 1440:
        return "1 day"
    if minutes == 10080:
        return "1 week"
    return f"{minutes} minutes"


def format_max_users(value):
    return "Unlimited" if int(value) == -1 else str(value)


async def owner_dashboard(query):
    if query.from_user.id != OWNER_ID:
        await query.answer("Owner only.", show_alert=True)
        return

    await query.edit_message_text(
        "👑 <b>Owner Dashboard</b>\n\n"
        "Select an owner command:",
        parse_mode="HTML",
        reply_markup=owner_dashboard_keyboard(),
    )


async def owner_create_promo_start(query, context):
    if query.from_user.id != OWNER_ID:
        await query.answer("Owner only.", show_alert=True)
        return

    context.user_data["promo_builder"] = {}
    await query.edit_message_text(
        "🎟️ <b>Create Promo Code</b>\n\n"
        "Send the promo code you want to create.\n\n"
        "Use letters and numbers only. Example: <code>FREE100</code>",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("❌ Cancel", callback_data="owner_dashboard")]
        ]),
    )


async def promo_page(query, context):
    context.user_data["awaiting_promo"] = True
    await query.edit_message_text(
        "🎟️ <b>Redeem Promo Code</b>\n\n"
        "Send the promo code as your next message.\n"
        "One user can use each promo code only once.",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("⬅️ Back", callback_data="home")]
        ]),
    )


async def promo_message(update, context):
    text = (update.message.text or "").strip()

    # Owner promo-creation wizard.
    builder = context.user_data.get("promo_builder")
    if builder is not None and update.effective_user.id == OWNER_ID:
        if not text.isalnum():
            await update.message.reply_text(
                "❌ Promo code must contain letters and numbers only.\n\n"
                "Send another code or press Cancel from the previous screen."
            )
            return

        builder["code"] = text.upper()
        await update.message.reply_text(
            f"🎟️ Code: <code>{html.escape(builder['code'])}</code>\n\n"
            "⏱️ <b>Select how long this promo should work:</b>",
            parse_mode="HTML",
            reply_markup=duration_keyboard(),
        )
        return

    # Normal user promo redemption.
    if not context.user_data.get("awaiting_promo"):
        return

    context.user_data["awaiting_promo"] = False
    code = text
    ok, message, credits = refer.redeem_promo(code, update.effective_user.id)

    if ok:
        refer.add_credits(update.effective_user.id, credits)
        reply = (
            "✅ <b>Promo code accepted!</b>\n\n"
            f"🎟️ Code: <code>{html.escape(code.upper())}</code>\n"
            f"📧 Credits added: <b>{credits}</b>\n"
            f"💳 Your email credits: <b>{refer.get_credits(update.effective_user.id)}</b>\n\n"
            "Each credit can create one email."
        )
    else:
        reply = f"❌ {html.escape(message)}"

    await update.message.reply_text(
        reply,
        parse_mode="HTML",
        reply_markup=main_keyboard(),
    )


async def owner_select_duration(query, context, minutes):
    if query.from_user.id != OWNER_ID:
        await query.answer("Owner only.", show_alert=True)
        return
    builder = context.user_data.get("promo_builder")
    if builder is None or "code" not in builder:
        await query.answer("Promo setup expired. Start again.", show_alert=True)
        return
    builder["minutes"] = int(minutes)
    await query.edit_message_text(
        f"🎟️ Code: <code>{html.escape(builder['code'])}</code>\n"
        f"⏱️ Duration: <b>{format_duration(builder['minutes'])}</b>\n\n"
        "📧 <b>Select how many email credits each user gets:</b>",
        parse_mode="HTML",
        reply_markup=credits_keyboard(),
    )


async def owner_select_credits(query, context, credits):
    if query.from_user.id != OWNER_ID:
        await query.answer("Owner only.", show_alert=True)
        return
    builder = context.user_data.get("promo_builder")
    if builder is None or "minutes" not in builder:
        await query.answer("Promo setup expired. Start again.", show_alert=True)
        return
    builder["credits"] = int(credits)
    await query.edit_message_text(
        f"🎟️ Code: <code>{html.escape(builder['code'])}</code>\n"
        f"⏱️ Duration: <b>{format_duration(builder['minutes'])}</b>\n"
        f"📧 Credits/user: <b>{builder['credits']}</b>\n\n"
        "👥 <b>Select how many users can redeem it:</b>",
        parse_mode="HTML",
        reply_markup=users_keyboard(),
    )


async def owner_select_users(query, context, max_users):
    if query.from_user.id != OWNER_ID:
        await query.answer("Owner only.", show_alert=True)
        return
    builder = context.user_data.get("promo_builder")
    if builder is None or "credits" not in builder:
        await query.answer("Promo setup expired. Start again.", show_alert=True)
        return

    builder["max_users"] = int(max_users)

    try:
        expires = refer.create_promo(
            builder["code"],
            builder["credits"],
            builder["minutes"],
            builder["max_users"],
            OWNER_ID,
        )
    except Exception as e:
        await query.edit_message_text(
            f"❌ <b>Could not create promo.</b>\n\n<code>{html.escape(str(e))}</code>",
            parse_mode="HTML",
            reply_markup=owner_dashboard_keyboard(),
        )
        context.user_data.pop("promo_builder", None)
        return

    code = builder["code"]
    credits = builder["credits"]
    minutes = builder["minutes"]
    users = builder["max_users"]
    context.user_data.pop("promo_builder", None)

    expires_text = "Never" if minutes == 0 else expires
    await query.edit_message_text(
        "✅ <b>Promo Created Successfully</b>\n\n"
        f"🎟️ Code: <code>{html.escape(code)}</code>\n"
        f"⏱️ Duration: <b>{format_duration(minutes)}</b>\n"
        f"📧 Credits/user: <b>{credits}</b>\n"
        f"👥 Max users: <b>{format_max_users(users)}</b>\n"
        f"⏳ Expires: <b>{html.escape(expires_text)}</b>",
        parse_mode="HTML",
        reply_markup=owner_dashboard_keyboard(),
    )


async def owner_promos_page(query):
    if query.from_user.id != OWNER_ID:
        await query.answer("Owner only.", show_alert=True)
        return

    rows = refer.promo_list()
    if not rows:
        text = "🎟️ <b>Promo Codes</b>\n\nNo promo codes yet."
    else:
        lines = ["🎟️ <b>Promo Codes</b>"]
        now = datetime.now(timezone.utc)
        for row in rows:
            expires = datetime.fromisoformat(row["expires_at"])
            unlimited = int(row["max_users"]) == -1
            active = now < expires and (unlimited or row["used_users"] < row["max_users"])
            status = "ACTIVE" if active else "STOPPED"
            users = "∞" if unlimited else f"{row['used_users']}/{row['max_users']}"
            duration = "Never" if expires.year >= 9999 else expires.strftime("%Y-%m-%d %H:%M UTC")
            lines.append(
                f"\n<code>{html.escape(row['code'])}</code> — <b>{status}</b>\n"
                f"📧 Credits/user: {row['credits']}\n"
                f"👥 Users: {users}\n"
                f"⏳ Expires: {html.escape(duration)}"
            )
        text = "\n".join(lines)

    await query.edit_message_text(
        text,
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("⬅️ Owner Dashboard", callback_data="owner_dashboard")]
        ]),
    )


async def owner_stats_page(query):
    if query.from_user.id != OWNER_ID:
        await query.answer("Owner only.", show_alert=True)
        return
    rows = refer.promo_list()
    total_redemptions = sum(int(r["used_users"]) for r in rows)
    total_credits = sum(int(r["credits"]) * int(r["used_users"]) for r in rows)
    await query.edit_message_text(
        "👑 <b>Owner Stats</b>\n\n"
        f"🎟️ Promo codes: <b>{len(rows)}</b>\n"
        f"👥 Total promo redemptions: <b>{total_redemptions}</b>\n"
        f"📧 Credits distributed through promos: <b>{total_credits}</b>",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("⬅️ Owner Dashboard", callback_data="owner_dashboard")]
        ]),
    )


# Backward-compatible command handlers. The normal owner workflow is now button-based.
async def owner_create_promo(update, context):
    if update.effective_user.id != OWNER_ID:
        return
    await update.message.reply_text(
        "👑 Open <b>Owner Dashboard</b> from the bot menu to create a promo with buttons.",
        parse_mode="HTML",
        reply_markup=owner_dashboard_keyboard(),
    )


async def owner_promos(update, context):
    if update.effective_user.id != OWNER_ID:
        return
    rows = refer.promo_list()
    if not rows:
        await update.message.reply_text("No promo codes yet.")
        return
    lines = ["🎟️ <b>Promo Codes</b>"]
    now = datetime.now(timezone.utc)
    for row in rows:
        expires = datetime.fromisoformat(row["expires_at"])
        unlimited = int(row["max_users"]) == -1
        status = "ACTIVE" if now < expires and (unlimited or row["used_users"] < row["max_users"]) else "STOPPED"
        users = "∞" if unlimited else f"{row['used_users']}/{row['max_users']}"
        exp = "Never" if expires.year >= 9999 else row["expires_at"]
        lines.append(f"\n<code>{html.escape(row['code'])}</code> — {status}\nCredits: {row['credits']} | Users: {users}\nExpires: {html.escape(exp)}")
    await update.message.reply_text("\n".join(lines), parse_mode="HTML")


async def owner_stats(update, context):
    if update.effective_user.id != OWNER_ID:
        return
    rows = refer.promo_list()
    total_users = sum(int(r["used_users"]) for r in rows)
    await update.message.reply_text(
        f"👑 <b>Owner Stats</b>\n\n🎟️ Promo codes: <b>{len(rows)}</b>\n👥 Promo redemptions: <b>{total_users}</b>",
        parse_mode="HTML",
    )


async def force_join_ok(bot, user_id):
    if not FORCE_JOIN_CHANNEL:
        return True
    try:
        member = await bot.get_chat_member(FORCE_JOIN_CHANNEL, user_id)
        return member.status in {"member", "administrator", "creator"}
    except Exception:
        return False


async def force_join_check(update, context):
    if not FORCE_JOIN_CHANNEL:
        return True
    ok = await force_join_ok(context.bot, update.effective_user.id)
    if ok:
        return True

    url = FORCE_JOIN_URL or f"https://t.me/{FORCE_JOIN_CHANNEL.lstrip('@')}"
    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("📢 Join Channel", url=url)],
        [InlineKeyboardButton("✅ I Joined — Check", callback_data="check_join")],
    ])
    if update.callback_query:
        await update.callback_query.edit_message_text(
            "📢 <b>Join the channel first</b>\n\n"
            "You must join the required channel before using the bot.",
            parse_mode="HTML",
            reply_markup=keyboard,
        )
    else:
        await update.message.reply_text(
            "📢 <b>Join the channel first</b>",
            parse_mode="HTML",
            reply_markup=keyboard,
        )
    return False


# ============================================================
# STATS
# ============================================================

async def stats_page(query):
    user_id = query.from_user.id
    count = refer.referral_count(user_id)

    text = (
        "📊 <b>My Stats</b>\n\n"
        f"👥 Successful referrals: <b>{count}</b>\n"
        f"🎯 Required referrals: <b>{REQUIRED_REFERRALS}</b>\n"
        f"🎟️ Email credits: <b>{refer.get_credits(user_id)}</b>\n"
        f"📧 Mailbox active: "
        f"<b>{'Yes' if user_id in mailboxes else 'No'}</b>"
    )

    await query.edit_message_text(
        text,
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton(
                "⬅️ Back",
                callback_data="home"
            )]
        ]),
    )


# ============================================================
# CALLBACKS
# ============================================================

async def callback_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    data = query.data

    if data == "home":
        count = refer.referral_count(query.from_user.id)

        await query.edit_message_text(
            "📧 <b>Advanced Email Bot</b>\n\n"
            f"👥 Referrals: <b>{count}/{REQUIRED_REFERRALS}</b>\n\n"
            "Choose an option:",
            parse_mode="HTML",
            reply_markup=main_keyboard(),
        )

    elif data == "create_email":
        if await force_join_check(update, context):
            await create_email(query)

    elif data == "inbox":
        await inbox_page(query)

    elif data == "autocheck":
        await autocheck(query, context)

    elif data == "stop_autocheck":
        await stop_autocheck(query, context)

    elif data == "referral":
        await referral_page(query)

    elif data == "stats":
        await stats_page(query)

    elif data == "promo":
        await promo_page(query, context)

    elif data == "owner_dashboard":
        await owner_dashboard(query)

    elif data == "owner_create_promo":
        await owner_create_promo_start(query, context)

    elif data.startswith("promo_duration:"):
        await owner_select_duration(query, context, int(data.split(":", 1)[1]))

    elif data.startswith("promo_credits:"):
        await owner_select_credits(query, context, int(data.split(":", 1)[1]))

    elif data.startswith("promo_users:"):
        await owner_select_users(query, context, int(data.split(":", 1)[1]))

    elif data == "owner_promos":
        await owner_promos_page(query)

    elif data == "owner_stats":
        await owner_stats_page(query)

    elif data == "check_join":
        if await force_join_ok(context.bot, query.from_user.id):
            await query.edit_message_text(
                "✅ Channel membership confirmed.",
                reply_markup=main_keyboard(),
            )
        else:
            await force_join_check(update, context)

    elif data.startswith("read:"):
        message_id = data.split(":", 1)[1]
        await read_selected_email(
            query,
            message_id
        )


# ============================================================
# MAIN
# ============================================================

def main():
    if not BOT_TOKEN:
        raise SystemExit(
            "BOT_TOKEN is not set.\n"
            "Run: export BOT_TOKEN='YOUR_BOT_TOKEN'"
        )

    refer.init_db()

    app = (
        ApplicationBuilder()
        .token(BOT_TOKEN)
        .build()
    )

    app.add_handler(
        CommandHandler(
            "start",
            start
        )
    )

    app.add_handler(
        CallbackQueryHandler(
            callback_handler
        )
    )

    app.add_handler(
        MessageHandler(
            filters.TEXT & ~filters.COMMAND,
            promo_message,
        )
    )

    app.add_handler(CommandHandler("createpromo", owner_create_promo))
    app.add_handler(CommandHandler("promos", owner_promos))
    app.add_handler(CommandHandler("ownerstats", owner_stats))

    print("Advanced Email Bot is running...")
    app.run_polling()


if __name__ == "__main__":
    main()