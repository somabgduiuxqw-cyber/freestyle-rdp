import sqlite3
from pathlib import Path
from datetime import datetime, timezone

DB_PATH = Path(__file__).with_name("refer.db")


def _connect():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with _connect() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                first_started_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                referrer_id INTEGER
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS referrals (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                referrer_id INTEGER NOT NULL,
                referred_id INTEGER NOT NULL UNIQUE,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS promo_codes (
                code TEXT PRIMARY KEY,
                credits INTEGER NOT NULL,
                expires_at TEXT NOT NULL,
                max_users INTEGER NOT NULL,
                used_users INTEGER NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                created_by INTEGER NOT NULL
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS user_credits (
                user_id INTEGER PRIMARY KEY,
                credits INTEGER NOT NULL DEFAULT 0
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS promo_uses (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                code TEXT NOT NULL,
                user_id INTEGER NOT NULL,
                credits INTEGER NOT NULL,
                used_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(code, user_id)
            )
        """)
        conn.commit()


def register_user(user_id, referrer_id=None):
    init_db()
    try:
        referrer_id = int(referrer_id) if referrer_id is not None else None
    except (TypeError, ValueError):
        referrer_id = None

    if referrer_id == user_id:
        referrer_id = None

    with _connect() as conn:
        existing = conn.execute(
            "SELECT user_id, referrer_id FROM users WHERE user_id = ?",
            (user_id,),
        ).fetchone()

        if existing:
            return {
                "new_user": False,
                "credited": False,
                "referrer_id": existing["referrer_id"],
            }

        valid_referrer = False
        if referrer_id is not None:
            row = conn.execute(
                "SELECT user_id FROM users WHERE user_id = ?",
                (referrer_id,),
            ).fetchone()
            valid_referrer = row is not None

        stored_referrer = referrer_id if valid_referrer else None

        conn.execute(
            "INSERT INTO users (user_id, referrer_id) VALUES (?, ?)",
            (user_id, stored_referrer),
        )

        if stored_referrer is not None:
            conn.execute(
                "INSERT OR IGNORE INTO referrals (referrer_id, referred_id) VALUES (?, ?)",
                (stored_referrer, user_id),
            )

        conn.commit()

        return {
            "new_user": True,
            "credited": stored_referrer is not None,
            "referrer_id": stored_referrer,
        }


def referral_count(user_id):
    init_db()
    with _connect() as conn:
        row = conn.execute(
            "SELECT COUNT(*) AS count FROM referrals WHERE referrer_id = ?",
            (user_id,),
        ).fetchone()
        return int(row["count"])


def has_required_referral(user_id, required=1):
    return referral_count(user_id) >= required


def get_referrer(user_id):
    init_db()
    with _connect() as conn:
        row = conn.execute(
            "SELECT referrer_id FROM users WHERE user_id = ?",
            (user_id,),
        ).fetchone()
        return row["referrer_id"] if row else None


def _utc_now():
    return datetime.now(timezone.utc)


def create_promo(code, credits, minutes, max_users, created_by):
    init_db()
    code = code.strip().upper()
    if not code or not code.isalnum():
        raise ValueError("Promo code must contain only letters and numbers.")
    if credits < 1 or minutes < 1 or max_users < 1:
        raise ValueError("Credits, minutes and max users must all be at least 1.")

    expires_at = _utc_now().timestamp() + (minutes * 60)
    expires_iso = datetime.fromtimestamp(expires_at, timezone.utc).isoformat()

    with _connect() as conn:
        conn.execute(
            "INSERT INTO promo_codes (code, credits, expires_at, max_users, created_by) VALUES (?, ?, ?, ?, ?)",
            (code, credits, expires_iso, max_users, created_by),
        )
        conn.commit()

    return expires_iso


def redeem_promo(code, user_id):
    init_db()
    code = code.strip().upper()

    with _connect() as conn:
        promo = conn.execute(
            "SELECT * FROM promo_codes WHERE code = ?",
            (code,),
        ).fetchone()

        if not promo:
            return False, "Invalid promo code.", 0

        already = conn.execute(
            "SELECT 1 FROM promo_uses WHERE code = ? AND user_id = ?",
            (code, user_id),
        ).fetchone()

        if already:
            return False, "You have already used this promo code.", 0

        expires = datetime.fromisoformat(promo["expires_at"])
        if _utc_now() >= expires:
            return False, "This promo code has expired.", 0

        if promo["used_users"] >= promo["max_users"]:
            return False, "This promo code has reached its user limit.", 0

        credits = int(promo["credits"])
        conn.execute(
            "INSERT INTO promo_uses (code, user_id, credits) VALUES (?, ?, ?)",
            (code, user_id, credits),
        )
        conn.execute(
            "UPDATE promo_codes SET used_users = used_users + 1 WHERE code = ?",
            (code,),
        )
        conn.commit()

        return True, "Promo code redeemed successfully.", credits


def promo_list():
    init_db()
    with _connect() as conn:
        return conn.execute(
            "SELECT code, credits, expires_at, max_users, used_users FROM promo_codes ORDER BY created_at DESC"
        ).fetchall()


def add_credits(user_id, amount):
    init_db()
    with _connect() as conn:
        conn.execute(
            "INSERT INTO user_credits (user_id, credits) VALUES (?, ?) ON CONFLICT(user_id) DO UPDATE SET credits = credits + excluded.credits",
            (user_id, int(amount)),
        )
        conn.commit()


def get_credits(user_id):
    init_db()
    with _connect() as conn:
        row = conn.execute(
            "SELECT credits FROM user_credits WHERE user_id = ?",
            (user_id,),
        ).fetchone()
        return int(row["credits"]) if row else 0


def consume_credit(user_id):
    init_db()
    with _connect() as conn:
        row = conn.execute(
            "SELECT credits FROM user_credits WHERE user_id = ?",
            (user_id,),
        ).fetchone()
        if not row or int(row["credits"]) < 1:
            return False
        conn.execute(
            "UPDATE user_credits SET credits = credits - 1 WHERE user_id = ?",
            (user_id,),
        )
        conn.commit()
        return True
