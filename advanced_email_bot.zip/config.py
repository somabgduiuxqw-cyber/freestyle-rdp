# =========================
# OWNER / BOT CONFIGURATION
# =========================

# Paste your Telegram numeric user ID here.
OWNER_ID = 8686609563

# Paste your bot token here OR leave empty and use:
# export BOT_TOKEN="YOUR_TOKEN"
BOT_TOKEN = "8648563795:AAF1BAjODuGuBNOhuhpad-bpJab4wRalyOU"

# Force-join channel username, including @.
# Example: "@mychannel"
# Set to "" to disable force join.
FORCE_JOIN_CHANNEL = "@darknetwork_boy_64"

# Optional invite/public URL shown to users for joining.
# Example: "https://t.me/mychannel"
FORCE_JOIN_URL = "https://t.me/darknetwork_boy_64"

# Number of successful referrals required for normal email creation.
REQUIRED_REFERRALS = 1

# How often auto-check polls Mail.tm, in seconds.
AUTO_CHECK_SECONDS = 5
