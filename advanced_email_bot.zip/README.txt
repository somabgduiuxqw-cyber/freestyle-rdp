# Advanced Email Bot

## Files
- main.py — Telegram bot and Mail.tm integration
- refer.py — referrals, promo codes and email credits; creates refer.db automatically
- config.py — owner ID, bot token, force-join channel and settings
- refer.db — created automatically when the bot first starts

## Configuration
Open `config.py` and set:

```python
OWNER_ID = 123456789
BOT_TOKEN = "YOUR_BOT_TOKEN"
FORCE_JOIN_CHANNEL = "@yourchannel"
FORCE_JOIN_URL = "https://t.me/yourchannel"
```

You can leave `BOT_TOKEN` empty and instead use:

```bash
export BOT_TOKEN="YOUR_BOT_TOKEN"
```

The bot must be able to check members in the force-join channel. Add the bot to that channel with suitable admin/member-management access if Telegram requires it for membership checks.

## Install on Termux

```bash
pkg update
pkg install python unzip
pip install -U python-telegram-bot requests
```

Extract and run:

```bash
unzip advanced_email_bot.zip
cd advanced_email_bot
python main.py
```

## Referral rule

A user must have one successful referral before normal `Create New Email` works.

A user is credited only on their first `/start`. If they have already started the bot, a later referral link cannot be assigned to them. Self-referrals are not credited.

## Promo codes

Only the owner can create promo codes.

Command:

```text
/createpromo CODE CREDITS MINUTES MAX_USERS
```

Example:

```text
/createpromo FREE200 1 200000 100
```

Meaning:
- `FREE200` = promo code
- `1` = each successful redemption gives 1 email credit
- `200000` = code remains valid for 200000 minutes
- `100` = maximum 100 different users can redeem it

A user can redeem a particular promo code only once. Credits are stored in `refer.db`. One email credit is consumed when the user creates one email.

Promo credits allow the user to create an email without satisfying the normal referral requirement.

Owner commands:
- `/createpromo CODE CREDITS MINUTES MAX_USERS`
- `/promos` — list promo codes and status
- `/ownerstats` — basic promo statistics

## Force join

Set `FORCE_JOIN_CHANNEL` and `FORCE_JOIN_URL` in `config.py`. Users must join the configured channel before they can create an email.

## 24/7 hosting

A small VPS is a straightforward option: run the bot with a systemd service so it starts on boot and restarts after a crash. Oracle Cloud currently lists Always Free compute resources, including up to two AMD micro VMs or an Ampere A1 allocation, subject to its limits and availability. See Oracle's current Always Free documentation before choosing it.

PythonAnywhere also has paid Always-on tasks that can automatically restart a long-running process, but its current paid Developer plan starts at $10/month. A normal free console is not intended to be a permanent bot process.
