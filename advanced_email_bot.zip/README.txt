ATP NETWORK TERMUX BOT

Files:
- main.py
- config.py
- refer.py
- requirements.txt

Install on Termux:
    pkg update
    pkg install python
    pip install -r requirements.txt

Edit config:
    nano config.py

Put your real Telegram bot token in BOT_TOKEN.

Run:
    python main.py

The first run creates:
    refer.db

Email format:
    atpnetwork###########@uberip.com

The 11 digits are random for each new email.

IMPORTANT:
uberip.com must be a domain accepted by the email API. If it is not,
change EMAIL_DOMAIN in config.py to a supported domain.
