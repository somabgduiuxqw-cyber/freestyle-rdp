

## Independent Website Hosting

The `website/` folder is now independent. It can be hosted on the VPS as static files without running the Python backend on that VPS.

The backend remains in `backend/` and can be hosted on another server with unrestricted outbound HTTPS access.

Recommended architecture:

Browser -> VPS static website -> separate backend -> Mail.tm
