const CONFIG = {
  // Set this only if you want the website to use a separate backend.
  // Leave empty for the VPS-independent demo mode.
  BACKEND_URL: ""
};

const $ = (id) => document.getElementById(id);

function setStatus(message, error = false) {
  const el = $("status");
  if (el) {
    el.textContent = message;
    el.className = error ? "error" : "";
  }
}

function saveState(state) {
  localStorage.setItem("atp_temp_state", JSON.stringify(state));
}

function loadState() {
  try {
    return JSON.parse(localStorage.getItem("atp_temp_state") || "{}");
  } catch {
    return {};
  }
}

async function api(path, options = {}) {
  if (!CONFIG.BACKEND_URL) {
    throw new Error("Backend URL is not configured.");
  }
  const base = CONFIG.BACKEND_URL.replace(/\/$/, "");
  const res = await fetch(base + path, options);
  const text = await res.text();
  let data;
  try { data = JSON.parse(text); } catch { data = { detail: text }; }
  if (!res.ok) throw new Error(data.detail || `HTTP ${res.status}`);
  return data;
}

async function loadDomains() {
  if (!CONFIG.BACKEND_URL) {
    setStatus("Website is hosted independently. Configure a backend URL to enable live email service.");
    return [];
  }
  const data = await api("/domains");
  return data.domains || [];
}

async function createEmail() {
  setStatus("Connecting to email service...");
  try {
    const domains = await loadDomains();
    if (!domains.length) throw new Error("No backend/domain configured.");

    const domain = domains[0];
    const local = "atpnetwork" + Math.floor(10000000000 + Math.random() * 90000000000);
    const address = `${local}@${domain}`;
    const password = crypto.randomUUID() + "A1!";

    const account = await api("/accounts", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({address, password})
    });

    const token = await api("/token", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({address, password})
    });

    const state = { address, password, token: token.token, account };
    saveState(state);

    $("email").textContent = address;
    setStatus("Temporary email created.");
    await refreshInbox();
  } catch (e) {
    setStatus(e.message, true);
  }
}

async function refreshInbox() {
  const state = loadState();
  if (!state.token) {
    setStatus(CONFIG.BACKEND_URL ? "Create an email first." : "Backend URL is not configured.");
    return;
  }

  try {
    const data = await api(`/messages?token_value=${encodeURIComponent(state.token)}`);
    const messages = data["hydra:member"] || data.member || data.messages || [];
    const inbox = $("inbox");
    inbox.innerHTML = "";

    if (!messages.length) {
      inbox.innerHTML = "<p>No messages yet.</p>";
      return;
    }

    for (const msg of messages) {
      const row = document.createElement("button");
      row.className = "message";
      row.textContent = `${msg.from?.address || "Unknown"} — ${msg.subject || "(No subject)"}`;
      row.onclick = () => openMessage(msg.id);
      inbox.appendChild(row);
    }
    setStatus(`${messages.length} message(s) found.`);
  } catch (e) {
    setStatus(e.message, true);
  }
}

async function openMessage(id) {
  const state = loadState();
  try {
    const msg = await api(`/messages/${encodeURIComponent(id)}?token_value=${encodeURIComponent(state.token)}`);
    const box = $("message");
    box.innerHTML = "";

    const title = document.createElement("h3");
    title.textContent = msg.subject || "(No subject)";
    const sender = document.createElement("p");
    sender.textContent = `From: ${msg.from?.address || "Unknown"}`;
    const body = document.createElement("pre");
    body.textContent = msg.text || msg.intro || "No text content.";

    box.append(title, sender, body);
  } catch (e) {
    setStatus(e.message, true);
  }
}

function copyEmail() {
  const value = $("email")?.textContent;
  if (!value || value === "No email created") return;
  navigator.clipboard.writeText(value).then(() => setStatus("Email copied."));
}

document.addEventListener("DOMContentLoaded", () => {
  $("create")?.addEventListener("click", createEmail);
  $("refresh")?.addEventListener("click", refreshInbox);
  $("copy")?.addEventListener("click", copyEmail);

  const state = loadState();
  if (state.address) $("email").textContent = state.address;

  // No direct Mail.tm calls are made by this site.
  // If BACKEND_URL is empty, the page remains a standalone hosted frontend.
});
