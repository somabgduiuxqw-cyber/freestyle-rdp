# ATP NETWORK Independent Website

This website is designed to be hosted independently on your VPS.

## Important architecture

```text
Browser
   |
   v
Your VPS (static website)
```

The website does **not** call Mail.tm directly. This means your VPS only needs to serve HTML/CSS/JS.

If you later have a backend hosted somewhere with outbound HTTPS access, set this in `app.js`:

```js
BACKEND_URL: "https://your-backend-domain.example"
```

Then the browser will use that backend for domains, account creation, tokens and inbox requests.

## Host with Nginx

Copy the contents of this `website` folder to:

```text
/var/www/atp-network
```

Example:

```bash
sudo mkdir -p /var/www/atp-network
sudo cp -r ./* /var/www/atp-network/
```

Nginx example:

```nginx
server {
    listen 80;
    server_name your-domain.example;

    root /var/www/atp-network;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }
}
```

The VPS does not need Python or the backend just to serve this static frontend.
