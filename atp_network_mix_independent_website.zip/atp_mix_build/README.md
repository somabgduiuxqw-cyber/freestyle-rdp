# ATP NETWORK MIX VERSION

This package combines the Telegram temporary-email bot, browser website, and a shared backend.

## Architecture

Telegram Bot ──┐
               ├──> ATP NETWORK Backend ──> Mail.tm
Website ───────┘

The bot and website no longer call Mail.tm directly. The backend handles domain caching, throttling, and HTTP 429 backoff.

## 1. Start backend

```bash
cd backend
python3 -m pip install -r requirements.txt
export ATP_API_KEY=''
export MAILTM_API='https://api.mail.tm'
python3 -m uvicorn backend:app --host 0.0.0.0 --port 8080
```

For production, put HTTPS/reverse proxy in front of port 8080.

## 2. Start Telegram bot

Edit `bot/config.py` with your settings, then:

```bash
cd bot
python3 -m pip install requests 'python-telegram-bot[job-queue]>=21,<23'
export BOT_TOKEN='YOUR_BOT_TOKEN'
export ATP_BACKEND_URL='http://YOUR_SERVER_IP:8080'
# If backend has an API key, set the same key here.
export ATP_API_KEY=''
python3 main.py
```

## 3. Website

Edit the `window.ATP_BACKEND_URL` line in `website/index.html` to your backend URL, for example:

`https://your-domain.example`

Then serve the website folder with any static web server.

## Security

Do not put your Telegram bot token in the website. If the backend is public, HTTPS is strongly recommended. If you enable `ATP_API_KEY`, remember that a browser website must know that key, so it should only be used with a deployment where exposing that key is acceptable.
