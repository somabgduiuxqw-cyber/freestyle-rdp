# ATP NETWORK Temporary Email Website

Static HTML/CSS/JavaScript temporary-email website using the Mail.tm REST API directly from the browser.

## Files
- `index.html` — page
- `style.css` — design
- `app.js` — Mail.tm account/inbox logic

## Run
Open `index.html` in a browser or upload the three files to any static web host.

## Notes
- The browser creates a Mail.tm account and stores its credentials/token in localStorage on that browser.
- The site caches the available domain list for the current browser session.
- Inbox auto-refresh is 10 seconds to reduce API traffic. Manual refresh is available.
- Mail.tm documents an 8 requests/second/IP limit. The site should not be used to generate high-volume traffic.
- Keep a visible attribution/link to Mail.tm, as required by its API terms.
