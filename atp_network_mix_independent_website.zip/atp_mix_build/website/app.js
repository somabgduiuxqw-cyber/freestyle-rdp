const API = (window.ATP_BACKEND_URL || localStorage.getItem('atp_backend_url') || 'http://127.0.0.1:8080').replace(/\/$/, '');
const AUTO_REFRESH_MS = 10000;
const API_KEY = window.ATP_API_KEY || localStorage.getItem('atp_api_key') || '';

let mailbox = JSON.parse(localStorage.getItem('atp_mailbox') || 'null');
let domainCache = JSON.parse(sessionStorage.getItem('atp_domains') || 'null');
let timer = null;

const $ = id => document.getElementById(id);
const status = msg => $('status').textContent = msg;

async function api(path, options={}) {
  const res = await fetch(API + path, {
    ...options,
    headers: {'Accept':'application/json', ...(API_KEY ? {'X-API-Key': API_KEY} : {}), ...(options.headers||{})}
  });
  let data = null;
  try { data = await res.json(); } catch {}
  if (res.status === 429) throw new Error('Rate limit reached. Please wait a few seconds and try again.');
  if (!res.ok) throw new Error(data?.detail || data?.message || `HTTP ${res.status}`);
  return data;
}

async function getDomain() {
  if (domainCache?.length) return domainCache[0];
  const data = await api('/domains');
  const list = Array.isArray(data) ? data : (data['hydra:member'] || data.members || data.data || []);
  const active = list.filter(x => typeof x === 'string' || x.isActive !== false);
  const names = active.map(x => typeof x === 'string' ? x.replace(/^@/,'') : x.domain).filter(Boolean);
  if (!names.length) throw new Error('No active Mail.tm domain is available.');
  domainCache = names;
  sessionStorage.setItem('atp_domains', JSON.stringify(names));
  return names[0];
}

function randomAddress(domain) {
  const digits = Array.from({length:11}, () => Math.floor(Math.random()*10)).join('');
  return `atpnetwork${digits}@${domain}`;
}

async function createMailbox() {
  $('createBtn').disabled = true;
  status('Creating…');
  try {
    const domain = await getDomain();
    let created = false;
    let address, password;
    for (let i=0; i<3 && !created; i++) {
      address = randomAddress(domain);
      password = crypto.randomUUID() + crypto.randomUUID();
      try {
        await api('/accounts', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({address,password})});
        created = true;
      } catch (e) {
        if (!String(e.message).startsWith('HTTP 422')) throw e;
      }
    }
    if (!created) throw new Error('Could not create a unique mailbox. Try again.');
    const tokenData = await api('/token', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({address,password})});
    mailbox = {address,password,token:tokenData.token};
    localStorage.setItem('atp_mailbox', JSON.stringify(mailbox));
    $('email').textContent = address;
    $('domainInfo').textContent = `Domain: ${domain}`;
    $('copyBtn').disabled = false;
    $('refreshBtn').disabled = false;
    $('autoBtn').disabled = false;
    status('Ready');
    await refreshInbox();
  } catch (e) {
    status('Error');
    alert(e.message);
  } finally { $('createBtn').disabled = false; }
}

async function refreshInbox() {
  if (!mailbox) return;
  try {
    const data = await api('/messages', {headers:{Authorization:`Bearer ${mailbox.token}`}});
    const messages = Array.isArray(data) ? data : (data['hydra:member'] || data.members || data.data || []);
    renderInbox(messages);
    status(`${messages.length} message${messages.length===1?'':'s'}`);
  } catch (e) {
    status(e.message.includes('429') ? 'Rate limited' : 'Inbox error');
  }
}

function renderInbox(messages) {
  const box = $('inbox');
  if (!messages.length) { box.className='empty'; box.textContent='Inbox is empty.'; return; }
  box.className='';
  box.innerHTML = messages.map((m,i) => {
    const sender = typeof m.from === 'object' ? (m.from.address || 'Unknown') : (m.from || 'Unknown');
    return `<article class="mail" data-id="${escapeHtml(m.id)}"><div class="mail-top"><span class="subject">${m.seen?'📨':'🆕'} ${escapeHtml(m.subject || '(No subject)')}</span><span class="small">${escapeHtml((m.createdAt||'').replace('T',' ').slice(0,16))}</span></div><div class="sender">${escapeHtml(sender)}</div><div class="intro">${escapeHtml(m.intro || '')}</div></article>`;
  }).join('');
  box.querySelectorAll('.mail').forEach(el => el.addEventListener('click', () => openMessage(el.dataset.id)));
}

async function openMessage(id) {
  try {
    const m = await api('/messages/'+encodeURIComponent(id), {headers:{Authorization:`Bearer ${mailbox.token}`}});
    const sender = typeof m.from === 'object' ? (m.from.address || 'Unknown') : (m.from || 'Unknown');
    let body = m.text || m.intro || '';
    if (!body && Array.isArray(m.html)) body = m.html.join('\n').replace(/<[^>]+>/g,' ');
    $('dialogSubject').textContent = m.subject || '(No subject)';
    $('dialogMeta').textContent = `From: ${sender}`;
    $('dialogBody').textContent = body;
    const urls = [...new Set((body.match(/https?:\/\/[^\s<>"']+/g)||[]))];
    $('dialogLinks').innerHTML = urls.slice(0,10).map(u => `<a href="${escapeAttr(u)}" target="_blank" rel="noopener">${escapeHtml(u)}</a>`).join('');
    $('messageDialog').showModal();
  } catch(e) { alert(e.message); }
}

function escapeHtml(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function escapeAttr(v){return escapeHtml(v);}

$('createBtn').onclick = createMailbox;
$('refreshBtn').onclick = refreshInbox;
$('copyBtn').onclick = async () => { await navigator.clipboard.writeText(mailbox.address); status('Copied'); };
$('autoBtn').onchange = e => {
  clearInterval(timer); timer = null;
  if (e.target.checked) { refreshInbox(); timer = setInterval(refreshInbox, AUTO_REFRESH_MS); }
};
$('closeDialog').onclick = () => $('messageDialog').close();
$('messageDialog').addEventListener('click', e => { if(e.target === $('messageDialog')) $('messageDialog').close(); });

if (mailbox?.address && mailbox?.token) {
  $('email').textContent = mailbox.address;
  $('domainInfo').textContent = `Domain: ${mailbox.address.split('@')[1]}`;
  $('copyBtn').disabled = false;
  $('refreshBtn').disabled = false;
  $('autoBtn').disabled = false;
  refreshInbox();
}
