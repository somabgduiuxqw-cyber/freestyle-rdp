# ATP NETWORK Mixed Backend

This backend sits between the Telegram bot / website and the Mail.tm API.

## Architecture

Telegram bot ──┐
               ├──> ATP backend ──> Mail.tm
Website ───────┘

## Run on Ubuntu

```bash
apt update
apt install -y python3 python3-pip
cd /path/to/backend
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export ATP_API_KEY='change-this-to-a-long-random-key'
uvicorn backend:app --host 0.0.0.0 --port 8080
```

For production, put HTTPS/reverse proxy in front of this service.

## Endpoints

GET  /health
GET  /domains
POST /accounts
POST /token
GET  /messages?token_value=...&page=1
GET  /messages/{message_id}?token_value=...

Send the API key as:

`X-API-Key: YOUR_KEY`

## Important

The backend intentionally caches `/domains`, throttles outbound requests, and retries HTTP 429 with backoff. The website and Telegram bot should call this backend instead of calling Mail.tm directly.
