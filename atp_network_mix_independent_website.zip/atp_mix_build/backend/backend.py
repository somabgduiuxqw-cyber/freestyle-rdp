import asyncio
import os
import time
from typing import Any, Dict, Optional

import httpx
from fastapi import FastAPI, HTTPException, Header
from pydantic import BaseModel, Field
from fastapi.middleware.cors import CORSMiddleware

MAILTM = os.getenv("MAILTM_API", "https://api.mail.tm").rstrip("/")
API_KEY = os.getenv("ATP_API_KEY", "")
DOMAIN_CACHE_SECONDS = int(os.getenv("DOMAIN_CACHE_SECONDS", "900"))
MIN_REQUEST_INTERVAL = float(os.getenv("MIN_REQUEST_INTERVAL", "0.35"))

app = FastAPI(title="ATP NETWORK Temp Email Backend", version="2.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

_lock = asyncio.Lock()
_last_request = 0.0
_domains_cache = []
_domains_cache_at = 0.0


class CreateEmail(BaseModel):
    address: str = Field(min_length=3, max_length=320)
    password: str = Field(min_length=8, max_length=200)


class LoginEmail(BaseModel):
    address: str = Field(min_length=3, max_length=320)
    password: str = Field(min_length=8, max_length=200)


def auth_ok(key: Optional[str]) -> bool:
    return not API_KEY or key == API_KEY


async def throttled_get(client: httpx.AsyncClient, url: str, **kwargs):
    global _last_request
    async with _lock:
        wait = MIN_REQUEST_INTERVAL - (time.monotonic() - _last_request)
        if wait > 0:
            await asyncio.sleep(wait)
        response = await client.get(url, **kwargs)
        _last_request = time.monotonic()
    return response


async def throttled_post(client: httpx.AsyncClient, url: str, **kwargs):
    global _last_request
    async with _lock:
        wait = MIN_REQUEST_INTERVAL - (time.monotonic() - _last_request)
        if wait > 0:
            await asyncio.sleep(wait)
        response = await client.post(url, **kwargs)
        _last_request = time.monotonic()
    return response


async def mail_request(method: str, path: str, **kwargs):
    url = MAILTM + path
    last = None

    for attempt in range(3):
        try:
            async with httpx.AsyncClient(timeout=20, follow_redirects=True) as client:
                if method == "GET":
                    r = await throttled_get(client, url, **kwargs)
                else:
                    r = await throttled_post(client, url, **kwargs)

            if r.status_code == 429:
                retry_after = r.headers.get("Retry-After")
                delay = float(retry_after) if retry_after and retry_after.isdigit() else (2 ** attempt) + 1
                await asyncio.sleep(min(delay, 10))
                last = r
                continue

            return r
        except (httpx.HTTPError, OSError) as e:
            last = e
            await asyncio.sleep(0.7 * (attempt + 1))

    if isinstance(last, Exception):
        raise HTTPException(502, f"Mail service connection failed: {last}")
    return last


def json_or_error(r: httpx.Response) -> Any:
    if r.status_code >= 400:
        detail = r.text[:1000]
        raise HTTPException(r.status_code, detail)
    try:
        return r.json()
    except Exception:
        raise HTTPException(502, "Mail service returned invalid JSON")


def extract_domains(payload: Any):
    if isinstance(payload, list):
        return payload
    if isinstance(payload, dict):
        for key in ("hydra:member", "member", "members", "data", "domains"):
            value = payload.get(key)
            if isinstance(value, list):
                return value
    return []


async def get_domains():
    global _domains_cache, _domains_cache_at
    now = time.monotonic()
    if _domains_cache and now - _domains_cache_at < DOMAIN_CACHE_SECONDS:
        return _domains_cache

    r = await mail_request("GET", "/domains")
    data = json_or_error(r)
    domains = extract_domains(data)
    active = []
    for item in domains:
        if isinstance(item, dict) and item.get("isActive", True):
            d = item.get("domain")
            if d:
                active.append(d)
    if not active:
        raise HTTPException(503, "No active email domains available")
    _domains_cache = active
    _domains_cache_at = now
    return active


def check_key(key: Optional[str]):
    if not auth_ok(key):
        raise HTTPException(401, "Invalid API key")

def bearer_from_header(authorization: Optional[str]):
    if not authorization:
        return None
    if authorization.lower().startswith("bearer "):
        return authorization[7:].strip()
    return None


@app.get("/health")
async def health():
    return {"ok": True, "service": "ATP NETWORK backend"}


@app.get("/domains")
async def domains(x_api_key: Optional[str] = Header(default=None, alias="X-API-Key")):
    check_key(x_api_key)
    return {"domains": await get_domains()}


@app.post("/accounts")
async def create_account(body: CreateEmail, x_api_key: Optional[str] = Header(default=None, alias="X-API-Key")):
    check_key(x_api_key)
    r = await mail_request(
        "POST",
        "/accounts",
        json={"address": body.address, "password": body.password},
    )
    return json_or_error(r)


@app.post("/token")
async def token(body: LoginEmail, x_api_key: Optional[str] = Header(default=None, alias="X-API-Key")):
    check_key(x_api_key)
    r = await mail_request(
        "POST",
        "/token",
        json={"address": body.address, "password": body.password},
    )
    return json_or_error(r)


@app.get("/messages")
async def messages(token_value: Optional[str] = None, page: int = 1, x_api_key: Optional[str] = Header(default=None, alias="X-API-Key"), authorization: Optional[str] = Header(default=None)):
    check_key(x_api_key)
    token_value = token_value or bearer_from_header(authorization)
    if not token_value:
        raise HTTPException(401, "Mailbox token required")
    r = await mail_request(
        "GET",
        "/messages",
        params={"page": page},
        headers={"Authorization": f"Bearer {token_value}"},
    )
    return json_or_error(r)


@app.get("/messages/{message_id}")
async def message(message_id: str, token_value: Optional[str] = None, x_api_key: Optional[str] = Header(default=None, alias="X-API-Key"), authorization: Optional[str] = Header(default=None)):
    check_key(x_api_key)
    token_value = token_value or bearer_from_header(authorization)
    if not token_value:
        raise HTTPException(401, "Mailbox token required")
    r = await mail_request(
        "GET",
        f"/messages/{message_id}",
        headers={"Authorization": f"Bearer {token_value}"},
    )
    return json_or_error(r)
